
import Data.MachO

import Foreign.ForeignPtr
import Foreign.LibFFI
import Foreign.Marshal
import Foreign.Ptr
import Foreign.Storable
import GHC.ForeignPtr                                     ( mallocPlainForeignPtrAlignedBytes )
import Text.Printf
import qualified Data.ByteString                          as B

objFile :: FilePath
objFile = "map.o"

len :: Int
len = 32

main :: IO ()
main = do
  putStrLn "loading object file..."
  obj         <- B.readFile objFile
  (funs, _oc) <- loadObject obj

  let Just map' = lookup "map" (functionTable funs)

  printf "\n"
  printf "got function 'map' at %s\n" (show map')

  xs  <- mallocPlainForeignPtrAlignedBytes (len * sizeOf (undefined::Float)) 32
  ys  <- mallocPlainForeignPtrAlignedBytes (len * sizeOf (undefined::Float)) 32

  withForeignPtr   xs $ \p_xs -> do
    withForeignPtr ys $ \p_ys -> do
      pokeArray p_xs [0..(fromIntegral len-1) :: Float]
      fillBytes p_ys 0 (len * sizeOf (undefined::Float))

      let start = argInt64 0
          end   = argInt64 (fromIntegral len)

      putStrLn "calling foreign function"
      callFFI map' retVoid [start, end, argPtr p_ys, end, argPtr p_xs, end]

      inp <- peekArray len (p_xs :: Ptr Float)
      printf "input array:  %s\n" (show inp)

      res <- peekArray len (p_ys :: Ptr Float)
      printf "output array: %s" (show res)

  return ()

