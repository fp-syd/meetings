#!/bin/bash

set -xe

stack build
stack exec ghc -- --make Test.hs -o demo

