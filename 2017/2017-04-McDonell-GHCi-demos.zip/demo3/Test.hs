
import Data.MachO

import Data.Int
import Foreign.ForeignPtr
import Foreign.LibFFI
import Foreign.Marshal
import Foreign.Ptr
import Foreign.Storable
import GHC.ForeignPtr                                     ( mallocPlainForeignPtrAlignedBytes )
import Text.Printf
import qualified Data.ByteString                          as B

objFile :: FilePath
objFile = "fill.o"

len :: Int
len = 32

main :: IO ()
main = do
  putStrLn "loading object file..."
  obj         <- B.readFile objFile
  (funs, _oc) <- loadObject obj

  let Just fill' = lookup "fill" (functionTable funs)

  printf "\n"
  printf "got function 'fill' at %s\n" (show fill')

  xs  <- mallocPlainForeignPtrAlignedBytes (len * sizeOf (undefined::Int64)) 32

  withForeignPtr   xs $ \p_xs -> do
    let start = argInt64 0
        end   = argInt64 (fromIntegral len)

    fillBytes p_xs 0xff (len * sizeOf (undefined::Int64))

    inp <- peekArray len (p_xs :: Ptr Int64)
    printf "input array: %s\n" (show inp)

    putStrLn "calling foreign function"
    callFFI fill' retVoid [start, end, argPtr p_xs, end]

    res <- peekArray len (p_xs :: Ptr Int64)
    printf "got result:  %s\n" (show res)

  return ()

