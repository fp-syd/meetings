#include <Rts.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#define OBJPATH "map.o"
#define N 31

typedef void map(int64_t start, int64_t end, float* p_out, int64_t sz_out, float* p_in, int64_t sz_in);

int main(int argc, char *argv[])
{
    map *f;
    int ok, i;
    float* xs = NULL;
    float* ys = NULL;

    posix_memalign((void**) &xs, 16, N*sizeof(float));
    posix_memalign((void**) &ys, 16, N*sizeof(float));

    if (!xs || !ys) {
        errorBelch("posix_memalign failed");
        exit(1);
    }

    hs_init(&argc, &argv);

    initLinker();

    ok = loadObj(OBJPATH);
    if (!ok) {
        errorBelch("loadObj(%s) failed", OBJPATH);
        exit(1);
    }

    ok = resolveObjs();
    if (!ok) {
        errorBelch("resolveObjs failed");
        exit(1);
    }

#ifdef darwin_HOST_OS
    f = lookupSymbol("_map");
#else
    f = lookupSymbol("map");
#endif
    if (!f) {
        errorBelch("lookupSymbol failed");
        exit(1);
    }

    for (i=0; i<N; ++i) {
        xs[i] = (float) i;
    }

    printf("array size is %d\n", N);
    printf("calling function...\n");
    f(0, N, ys, N, xs, N);
    printf("ok\n");

    for (i=0; i<N; ++i) {
        printf("%.1f ", ys[i]);
    }
    printf("\n");

    ok = unloadObj(OBJPATH);
    if (!ok) {
        errorBelch("unloadObj(%s) failed", OBJPATH);
        exit(1);
    }

    free(xs);
    free(ys);

    return 0;
}

