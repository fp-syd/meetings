#!/bin/bash

set -xe

llc -filetype=obj -mcpu=native map.ll
ghc --make -no-hs-main test.c

